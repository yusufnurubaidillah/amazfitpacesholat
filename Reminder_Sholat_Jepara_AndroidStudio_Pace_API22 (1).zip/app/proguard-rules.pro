# Proguard rules for Amazfit Pace
-keepattributes *Annotation*
