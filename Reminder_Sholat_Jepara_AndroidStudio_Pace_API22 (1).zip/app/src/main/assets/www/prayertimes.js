/**
 * Algoritma Jadwal Sholat Kemenag RI untuk Jepara, Jawa Tengah
 * Koordinat: -6.5888 LS, 110.6783 BT | Waktu: WIB (GMT+7)
 * Ihtiyat: +2 Menit
 */
var JeparaPrayerEngine = (function() {
  var LATITUDE = -6.5888;
  var LONGITUDE = 110.6783;
  var TIMEZONE = 7.0;
  var IHTIYAT = 2; // menit kehati-hatian standar Kemenag

  function toRad(deg) { return (deg * Math.PI) / 180.0; }
  function toDeg(rad) { return (rad * 180.0) / Math.PI; }

  function julianDate(year, month, day) {
    if (month <= 2) {
      year -= 1;
      month += 12;
    }
    var A = Math.floor(year / 100);
    var B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5;
  }

  function sunPosition(jd) {
    var D = jd - 2451545.0;
    var g = (357.529 + 0.98560028 * D) % 360;
    var q = (280.459 + 0.98564736 * D) % 360;
    var L = (q + 1.915 * Math.sin(toRad(g)) + 0.020 * Math.sin(toRad(2 * g))) % 360;
    var e = 23.439 - 0.00000036 * D;

    var sinDec = Math.sin(toRad(e)) * Math.sin(toRad(L));
    var declination = toDeg(Math.asin(sinDec));

    var RA = toDeg(Math.atan2(Math.cos(toRad(e)) * Math.sin(toRad(L)), Math.cos(toRad(L)))) / 15.0;
    if (RA < 0) RA += 24;

    var EqT = q / 15.0 - RA;
    return { declination: declination, equationOfTime: EqT };
  }

  function hourToHM(hourDecimal) {
    while (hourDecimal < 0) hourDecimal += 24;
    while (hourDecimal >= 24) hourDecimal -= 24;
    var totalMin = Math.round(hourDecimal * 60);
    var h = Math.floor(totalMin / 60);
    var m = totalMin % 60;
    return {
      hours: h,
      minutes: m,
      formatted: (h < 10 ? '0' + h : '' + h) + ':' + (m < 10 ? '0' + m : '' + m)
    };
  }

  return {
    calculateToday: function(date) {
      date = date || new Date();
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var day = date.getDate();

      var jd = julianDate(year, month, day);
      var sun = sunPosition(jd);
      var dec = sun.declination;
      var eqt = sun.equationOfTime;

      // Transit (Dzuhur)
      var transit = 12 + TIMEZONE - (LONGITUDE / 15.0) - eqt;
      var dzuhurDec = transit + (IHTIYAT / 60.0);

      // Ashar (Mazhab Syafi'i: shadow length = object + shadow at noon)
      var noonAlt = 90 - Math.abs(LATITUDE - dec);
      var asrAlt = toDeg(Math.atan(1.0 / (1.0 + Math.tan(toRad(Math.abs(LATITUDE - dec))))));
      var asrHA = toDeg(Math.acos((Math.sin(toRad(asrAlt)) - Math.sin(toRad(LATITUDE)) * Math.sin(toRad(dec))) / (Math.cos(toRad(LATITUDE)) * Math.cos(toRad(dec))))) / 15.0;
      var asharDec = transit + asrHA + (IHTIYAT / 60.0);

      // Maghrib (Sun altitude = -0.8333)
      var sunsetHA = toDeg(Math.acos((Math.sin(toRad(-0.8333)) - Math.sin(toRad(LATITUDE)) * Math.sin(toRad(dec))) / (Math.cos(toRad(LATITUDE)) * Math.cos(toRad(dec))))) / 15.0;
      var maghribDec = transit + sunsetHA + (IHTIYAT / 60.0);

      // Isya (Kemenag RI: Sun angle = -18°)
      var ishaHA = toDeg(Math.acos((Math.sin(toRad(-18.0)) - Math.sin(toRad(LATITUDE)) * Math.sin(toRad(dec))) / (Math.cos(toRad(LATITUDE)) * Math.cos(toRad(dec))))) / 15.0;
      var isyaDec = transit + ishaHA + (IHTIYAT / 60.0);

      // Subuh (Kemenag RI: Sun angle = -20°)
      var fajrHA = toDeg(Math.acos((Math.sin(toRad(-20.0)) - Math.sin(toRad(LATITUDE)) * Math.sin(toRad(dec))) / (Math.cos(toRad(LATITUDE)) * Math.cos(toRad(dec))))) / 15.0;
      var subuhDec = transit - fajrHA + (IHTIYAT / 60.0);

      // Imsak: 10 menit sebelum subuh
      var imsakDec = subuhDec - (10.0 / 60.0);

      // Terbit (Sunrise)
      var terbitDec = transit - sunsetHA;

      return [
        { key: 'imsak', name: 'Imsak', time: hourToHM(imsakDec), decimal: imsakDec },
        { key: 'subuh', name: 'Subuh', time: hourToHM(subuhDec), decimal: subuhDec },
        { key: 'terbit', name: 'Terbit', time: hourToHM(terbitDec), decimal: terbitDec },
        { key: 'dzuhur', name: 'Dzuhur', time: hourToHM(dzuhurDec), decimal: dzuhurDec },
        { key: 'ashar', name: 'Ashar', time: hourToHM(asharDec), decimal: asharDec },
        { key: 'maghrib', name: 'Maghrib', time: hourToHM(maghribDec), decimal: maghribDec },
        { key: 'isya', name: 'Isya', time: hourToHM(isyaDec), decimal: isyaDec },
      ];
    }
  };
})();
