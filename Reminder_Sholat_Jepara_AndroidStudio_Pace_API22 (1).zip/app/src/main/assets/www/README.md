# Reminder Sholat Jepara untuk Amazfit Pace

Aplikasi pengingat jadwal sholat otomatis di smartwatch Amazfit Pace (Android 5.1 Lollipop, API 22).

## Fitur
- Perhitungan jadwal sholat akurat untuk Jepara (Kemenag RI).
- Tampilan bulat disesuaikan dengan layar 320x300 pixel transflective LCD Pace.
- Alarm getaran saat waktu sholat tiba.
- Arah kiblat untuk Jepara: 294.6°.
