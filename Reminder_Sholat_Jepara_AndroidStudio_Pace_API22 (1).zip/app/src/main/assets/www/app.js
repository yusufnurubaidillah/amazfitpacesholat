// Reminder Sholat Jepara - Smartwatch Logic
document.addEventListener('DOMContentLoaded', function() {
  var liveClockEl = document.getElementById('liveClock');
  var nextPrayerNameEl = document.getElementById('nextPrayerName');
  var nextPrayerTimeEl = document.getElementById('nextPrayerTime');
  var countdownTextEl = document.getElementById('countdownText');
  var scheduleListEl = document.getElementById('scheduleList');
  var btnTestAdzan = document.getElementById('btnTestAdzan');

  var prayers = JeparaPrayerEngine.calculateToday(new Date());

  // Render horizontal strip
  function renderSchedule(activeKey) {
    scheduleListEl.innerHTML = '';
    prayers.forEach(function(p) {
      if (p.key === 'terbit') return; // lewati terbit di strip ringkas
      var div = document.createElement('div');
      div.className = 'prayer-pill ' + (p.key === activeKey ? 'active' : '');
      div.innerHTML = '<div class="p-name">' + p.name + '</div><div class="p-time">' + p.time.formatted + '</div>';
      scheduleListEl.appendChild(div);
    });
  }

  function update() {
    var now = new Date();
    var h = String(now.getHours()).padStart(2, '0');
    var m = String(now.getMinutes()).padStart(2, '0');
    var s = String(now.getSeconds()).padStart(2, '0');
    liveClockEl.textContent = h + ':' + m + ':' + s;

    var currentMinutes = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;

    // Find next prayer (Subuh, Dzuhur, Ashar, Maghrib, Isya)
    var mainPrayers = prayers.filter(function(p) {
      return ['subuh', 'dzuhur', 'ashar', 'maghrib', 'isya'].indexOf(p.key) !== -1;
    });

    var next = null;
    for (var i = 0; i < mainPrayers.length; i++) {
      var pMin = mainPrayers[i].time.hours * 60 + mainPrayers[i].time.minutes;
      if (pMin > currentMinutes) {
        next = mainPrayers[i];
        break;
      }
    }

    var isTomorrow = false;
    if (!next) {
      next = mainPrayers[0]; // Subuh besok
      isTomorrow = true;
    }

    nextPrayerNameEl.textContent = next.name + (isTomorrow ? ' (Besok)' : '');
    nextPrayerTimeEl.textContent = next.time.formatted;

    var targetMin = next.time.hours * 60 + next.time.minutes;
    if (isTomorrow) targetMin += 24 * 60;

    var diffMin = targetMin - currentMinutes;
    var diffHours = Math.floor(diffMin / 60);
    var diffRemainingMin = Math.floor(diffMin % 60);

    if (diffMin <= 1) {
      countdownTextEl.textContent = 'WAKTUNYA SHOLAT!';
      countdownTextEl.style.background = '#ef4444';
      countdownTextEl.style.color = '#ffffff';
    } else {
      countdownTextEl.textContent = (diffHours > 0 ? diffHours + 'j ' : '') + diffRemainingMin + 'm lagi';
      countdownTextEl.style.background = '#f59e0b';
      countdownTextEl.style.color = '#000000';
    }

    renderSchedule(next.key);
  }

  // Initial call & timer loop
  update();
  setInterval(update, 1000);

  // Vibration & Beep Test
  if (btnTestAdzan) {
    btnTestAdzan.onclick = function() {
      // Getar pola smartwatch
      if (navigator.vibrate) {
        navigator.vibrate([200, 100, 200, 100, 500]);
      }
      
      // Suara beep ringan via Web Audio API (jika speaker Pace aktif)
      try {
        var AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
          var ctx = new AudioContext();
          var osc = ctx.createOscillator();
          var gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
          osc.frequency.setValueAtTime(880, ctx.currentTime + 0.15); // A5
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.4);
        }
      } catch (e) {
        console.log('Audio not supported or muted');
      }

      btnTestAdzan.textContent = '✓ Bergetar!';
      setTimeout(function() {
        btnTestAdzan.textContent = '🔔 Tes Getar';
      }, 1500);
    };
  }
});
